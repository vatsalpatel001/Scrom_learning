
var nFindAPITries = 0;
var API = null;
var maxTries = 500;
var win = window;
// The ScanForAPI() function searches for an object named API_1484_11
// in the window that is passed into the function. If the object is
// found a reference to the object is returned to the calling function.
// If the instance is found the SCO now has a handle to the LMS
// provided API Instance. The function searches a maximum number
// of parents of the current window. If no object is found the
// function returns a null reference. This function also reassigns a
// value to the win parameter passed in, based on the number of
// parents. At the end of the function call, the win variable will be
// set to the upper most parent in the chain of parents.
function ScanForAPI(win)
{
   while ((win.API_1484_11 == null) && (win.parent != null) && (win.parent != win))
   {
      nFindAPITries++;
      if (nFindAPITries > maxTries)
      {
         return null;
      }
      win = win.parent;
   }
   return win.API_1484_11;
}

// The GetAPI() function begins the process of searching for the LMS
// provided API Instance. The function takes in a parameter that
// represents the current window. The function is built to search in a
// specific order and stop when the LMS provided API Instance is found.
// The function begins by searching the current window’s parent, if the
// current window has a parent. If the API Instance is not found, the
// function then checks to see if there are any opener windows. If
// the window has an opener, the function begins to look for the
// API Instance in the opener window.
function GetAPI(win)
{
   if ((win.parent != null) && (win.parent != win))
   {
      API = ScanForAPI(win.parent);
   }
   if ((API == null) && (win.opener != null))
   {
      API = ScanForAPI(win.opener);
   }
  }




//The following 4 lines handle our actions for this example

// get the API, Initialize the LMS, retrieve a value, set a value

GetAPI(win);

if(API){
API.Initialize("");	
API.SetValue("cmi.exit", "suspend");
}


//update storage


function SetStorage(str){
   let Sucess= (Number(JSON.parse(str)['lock_arr'].indexOf("true"))<0);
   str = str.replace(/\"/g,'*');
  localStorage.setItem(document.title,str);
//scrom bypass
  if(API){
   if(Sucess){
   API.SetValue("cmi.success_status","passed");
   API.SetValue("cmi.completion_status","completed");
   }
  	API.SetValue("cmi.suspend_data",str);
  }
}

function getStorage(){
	let str = localStorage.getItem(document.title);
	if(!str){str=""}
//scrom bypass		
	if(API){
		// console.log("kk")
		str = API.GetValue("cmi.suspend_data");
		}
		// console.log(str)
		if(str.length>0){
			str=str.replace(/\*/g,'"');
			// console.log(str)
			return	JSON.parse(str);
		}else{
			return "";
		}
}


// localStorage.clear();
 window.addEventListener('unload', function(event) {
   API.Terminate("");
      });

var Lock_arr = [];
if(getStorage()['lock_arr']?.length>0){
	Lock_arr = [...getStorage()['lock_arr']];
}
// console.log(Lock_arr)